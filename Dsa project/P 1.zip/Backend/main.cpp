#include <iostream>
#include <httplib.h>
#include <nlohmann/json.hpp>
#include <cstdlib>
#include <vector>
#include <queue>
#include <climits>

using namespace std;
using json = nlohmann::json;

int INF = INT_MAX;
int vertex = 40; // 34 Campus Locations + 6 Road Junctions
vector<vector<pair<int, int>>> graph(vertex);

void addDirectedEdge(int u, int v, int weight, vector<vector<pair<int, int>>> &graph);
pair<vector<int>, int> dijkstra(int source, int destination, vector<vector<pair<int, int>>> &graph);

int main()
{
    httplib::Server server;

    server.set_default_headers({{"Access-Control-Allow-Origin", "*"},
                                {"Access-Control-Allow-Methods", "GET, POST, OPTIONS"},
                                {"Access-Control-Allow-Headers", "Content-Type"}});

    /*
     * Campus Locations (0 to 33):
     * 0: Main Gate, 1: Gate 2, 2: Gate 3, 3: Bus Stand, 4: Play Ground 1,
     * 5: Play Ground 2, 6: Garden, 7: Canteen, 8: Central Corridor,
     * 9: Library (b), 10: Gate (Top-Left), 11: Info Desk, 12: Boys Common Room (b),
     * 13: Mosque (2nd), 14: Pharmacy Dept (b), 15: Plaza (2nd), 16: Sinat (3rd),
     * 17: Inventory Room (b), 18: Auditorium (b), 19: EEE Lab (b), 20: Girls Common Room,
     * 21: CR Center, 22: American Corner (2nd), 23: NCC Bank, 24: CSE Faculty,
     * 25: BBA Dept (2nd), 26: EEE Prog. Office, 27: Lift, 28: CSE Prog. Office,
     * 29: Parking, 30: Medical, 31: Gate (Top-Right), 32: Gate (Bottom-Right),
     * 33: Stair
     *
     * Road Junctions (34 to 39):
     * 34: Main Entry T-Junction, 35: Top-Left Curve Junction, 36: Top-Right Outer Junction,
     * 37: South Corridor Junction (Parking Turn), 38: Central Spine Junction, 39: East Corridor Junction
     */

    // --- 1. Bottom Outer Road (Routes 23, 31, 80) ---
    addDirectedEdge(0, 1, 90, graph);  // Main Gate -> Gate 2 (90m)
    addDirectedEdge(0, 2, 140, graph); // Main Gate -> Gate 3 (140m)

    // --- 2. Left & Top Outer Perimeter (Routes 23-38, 69-92) ---
    addDirectedEdge(1, 3, 100, graph); // Gate 2 -> Bus Stand (100m)
    addDirectedEdge(3, 35, 45, graph); // Bus Stand -> Top-Left Curve (45m)
    addDirectedEdge(35, 3, 45, graph); // Top-Left Curve -> Bus Stand (45m)
    addDirectedEdge(35, 4, 85, graph); // Top-Left Curve -> Play Ground 1 (85m)
    addDirectedEdge(4, 35, 85, graph); // Play Ground 1 -> Top-Left Curve (85m)
    addDirectedEdge(4, 5, 160, graph); // Play Ground 1 -> Play Ground 2 (160m)
    addDirectedEdge(5, 4, 160, graph); // Play Ground 2 -> Play Ground 1 (160m)

    // --- 3. Right Outer Perimeter (Routes 26-27, 34-35, 81-92) ---
    addDirectedEdge(2, 7, 110, graph); // Gate 3 -> Canteen (110m)
    addDirectedEdge(7, 6, 80, graph);  // Canteen -> Garden (80m)
    addDirectedEdge(6, 7, 80, graph);  // Garden -> Canteen (80m)
    addDirectedEdge(6, 36, 35, graph); // Garden -> Top-Right Junction (35m)
    addDirectedEdge(36, 6, 35, graph); // Top-Right Junction -> Garden (35m)
    addDirectedEdge(36, 5, 40, graph); // Top-Right Junction -> Play Ground 2 (40m)
    addDirectedEdge(5, 36, 40, graph); // Play Ground 2 -> Top-Right Junction (40m)

    // --- 4. Main Gate & Gate 2 Entry Curves (Routes 1-80) ---
    addDirectedEdge(0, 34, 35, graph);  // Main Gate -> Main Entry T-Junction (35m)
    addDirectedEdge(1, 34, 95, graph);  // Gate 2 -> Main Entry T-Junction (95m)
    addDirectedEdge(34, 9, 45, graph);  // Main Entry T-Junction -> Library (b) (45m)
    addDirectedEdge(34, 37, 40, graph); // Main Entry T-Junction -> South Junction (40m)
    addDirectedEdge(37, 8, 25, graph);  // South Junction -> Central Corridor (25m)
    addDirectedEdge(8, 33, 15, graph);  // Central Corridor -> Stair (15m)

    // --- 5. Bus Stand & Top-Left Gate Connections (Routes 69-92) ---
    addDirectedEdge(9, 3, 90, graph);   // Library (b) -> Bus Stand (90m)
    addDirectedEdge(3, 9, 90, graph);   // Bus Stand -> Library (b) (90m)
    addDirectedEdge(35, 10, 40, graph); // Top-Left Curve -> Top-Left Gate (40m)
    addDirectedEdge(10, 35, 40, graph); // Top-Left Gate -> Top-Left Curve (40m)

    // --- 6. Top-Left Academic Wing ---
    addDirectedEdge(10, 11, 30, graph); // Top-Left Gate -> Info Desk (30m)
    addDirectedEdge(11, 10, 30, graph); // Info Desk -> Top-Left Gate (30m)
    addDirectedEdge(11, 13, 35, graph); // Info Desk -> Mosque (2nd) (35m)
    addDirectedEdge(13, 14, 25, graph); // Mosque (2nd) -> Pharmacy Dept (b) (25m)
    addDirectedEdge(14, 15, 30, graph); // Pharmacy Dept (b) -> Plaza (2nd) (30m)

    addDirectedEdge(11, 12, 30, graph); // Info Desk -> Boys Common Room (b) (30m)
    addDirectedEdge(12, 11, 30, graph); // Boys Common Room (b) -> Info Desk (30m)
    addDirectedEdge(12, 16, 25, graph); // Boys Common Room (b) -> Sinat (3rd) (25m)
    addDirectedEdge(16, 38, 25, graph); // Sinat (3rd) -> Central Spine Junction (25m)

    // --- 7. Central Spine & Stair Routes (Routes 28-30, 36-38, 43-47) ---
    addDirectedEdge(33, 38, 35, graph); // Stair -> Central Spine Junction (35m)
    addDirectedEdge(38, 33, 35, graph); // Central Spine Junction -> Stair (35m)
    addDirectedEdge(38, 15, 25, graph); // Central Spine Junction -> Plaza (2nd) (25m)
    addDirectedEdge(15, 38, 25, graph); // Plaza (2nd) -> Central Spine Junction (25m)

    // --- 8. Left Courtyard & Basement Loop (Routes 8-17, 55-68, 74-79, 87-92, 98-105) ---
    addDirectedEdge(9, 17, 50, graph);  // Library (b) -> Inventory Room (b) (50m)
    addDirectedEdge(17, 9, 50, graph);  // Inventory Room (b) -> Library (b) (50m)
    addDirectedEdge(17, 18, 30, graph); // Inventory Room (b) -> Auditorium (b) (30m)
    addDirectedEdge(18, 17, 30, graph); // Auditorium (b) -> Inventory Room (b) (30m)
    addDirectedEdge(18, 19, 35, graph); // Auditorium (b) -> EEE Lab (b) (35m)
    addDirectedEdge(19, 18, 35, graph); // EEE Lab (b) -> Auditorium (b) (35m)
    addDirectedEdge(8, 19, 30, graph);  // Central Corridor -> EEE Lab (b) (30m)
    addDirectedEdge(19, 8, 30, graph);  // EEE Lab (b) -> Central Corridor (30m)

    // --- 9. Top-Right Wing (Girls Common, CR Center, American Corner) ---
    addDirectedEdge(38, 20, 40, graph); // Central Spine Junction -> Girls Common Room (40m)
    addDirectedEdge(20, 38, 40, graph); // Girls Common Room -> Central Spine Junction (40m)
    addDirectedEdge(20, 21, 45, graph); // Girls Common Room -> CR Center (45m)
    addDirectedEdge(21, 20, 45, graph); // CR Center -> Girls Common Room (45m)
    addDirectedEdge(38, 22, 35, graph); // Central Spine Junction -> American Corner (2nd) (35m)
    addDirectedEdge(22, 21, 40, graph); // American Corner (2nd) -> CR Center (40m)

    // --- 10. Bottom-Right Wing & Offices ---
    addDirectedEdge(8, 23, 25, graph);  // Central Corridor -> NCC Bank (25m)
    addDirectedEdge(23, 22, 30, graph); // NCC Bank -> American Corner (2nd) (30m)
    addDirectedEdge(23, 25, 35, graph); // NCC Bank -> BBA Dept (2nd) (35m)

    addDirectedEdge(8, 24, 30, graph);  // Central Corridor -> CSE Faculty (30m)
    addDirectedEdge(24, 25, 25, graph); // CSE Faculty -> BBA Dept (2nd) (25m)
    addDirectedEdge(25, 27, 25, graph); // BBA Dept (2nd) -> Lift (25m)

    addDirectedEdge(21, 26, 35, graph); // CR Center -> EEE Prog. Office (35m)
    addDirectedEdge(26, 21, 35, graph); // EEE Prog. Office -> CR Center (35m)
    addDirectedEdge(26, 27, 20, graph); // EEE Prog. Office -> Lift (20m)
    addDirectedEdge(27, 26, 20, graph); // Lift -> EEE Prog. Office (20m)
    addDirectedEdge(27, 39, 20, graph); // Lift -> East Corridor Junction (20m)
    addDirectedEdge(39, 27, 20, graph); // East Corridor Junction -> Lift (20m)
    addDirectedEdge(39, 28, 20, graph); // East Corridor Junction -> CSE Prog. Office (20m)
    addDirectedEdge(28, 39, 20, graph); // CSE Prog. Office -> East Corridor Junction (20m)

    // --- 11. Parking & Medical Loop (Routes 3-4, 21-22, 48-61, 93-105) ---
    addDirectedEdge(37, 29, 65, graph); // South Junction -> Parking (65m)
    addDirectedEdge(29, 30, 15, graph); // Parking -> Medical (15m)
    addDirectedEdge(30, 39, 35, graph); // Medical -> East Corridor Junction (35m)
    addDirectedEdge(29, 39, 35, graph); // Parking -> East Corridor Junction (35m)
    addDirectedEdge(39, 29, 35, graph); // East Corridor Junction -> Parking (35m)

    // --- 12. Right Side Gates to Garden & Canteen (Routes 15-17, 52-54, 71-73, 81-105) ---
    addDirectedEdge(21, 31, 35, graph); // CR Center -> Top-Right Gate (35m)
    addDirectedEdge(31, 21, 35, graph); // Top-Right Gate -> CR Center (35m)
    addDirectedEdge(31, 36, 45, graph); // Top-Right Gate -> Top-Right Junction (45m)
    addDirectedEdge(36, 31, 45, graph); // Top-Right Junction -> Top-Right Gate (45m)

    addDirectedEdge(39, 32, 30, graph); // East Corridor Junction -> Bottom-Right Gate (30m)
    addDirectedEdge(32, 39, 30, graph); // Bottom-Right Gate -> East Corridor Junction (30m)
    addDirectedEdge(32, 7, 40, graph);  // Bottom-Right Gate -> Canteen (40m)
    addDirectedEdge(7, 32, 40, graph);  // Canteen -> Bottom-Right Gate (40m)

    server.Options("/find-path", [](const httplib::Request &req, httplib::Response &res)
                   { res.status = 204; });

    server.Post("/find-path", [](const httplib::Request &req, httplib::Response &res)
                {
        try
        {
            json data = json::parse(req.body);
            int source = data.at("source").get<int>();
            int destination = data.at("destination").get<int>();

            auto [path, totalDist] = dijkstra(source, destination, graph);

            json response = {
                {"path", path},
                {"distance", totalDist},
                {"reachable", !path.empty()}
            };

            res.set_content(response.dump(), "application/json");
        }
        catch (const exception &e)
        {
            res.status = 400;
            res.set_content(R"({"error":"Invalid input"})", "application/json");
        } });

    server.Get("/locations", [](const httplib::Request &req, httplib::Response &res)
               {
        json locations = {
            {"locations", {
                {{"id", 0}, {"name", "Main Gate"}},
                {{"id", 1}, {"name", "Gate 2"}},
                {{"id", 2}, {"name", "Gate 3"}},
                {{"id", 3}, {"name", "Bus Stand"}},
                {{"id", 4}, {"name", "Play Ground 1"}},
                {{"id", 5}, {"name", "Play Ground 2"}},
                {{"id", 6}, {"name", "Garden"}},
                {{"id", 7}, {"name", "Canteen"}},
                {{"id", 8}, {"name", "Central Corridor"}},
                {{"id", 9}, {"name", "Library (b)"}},
                {{"id", 10}, {"name", "Gate (Top-Left)"}},
                {{"id", 11}, {"name", "Info Desk"}},
                {{"id", 12}, {"name", "Boys Common Room (b)"}},
                {{"id", 13}, {"name", "Mosque (2nd)"}},
                {{"id", 14}, {"name", "Pharmacy Dept (b)"}},
                {{"id", 15}, {"name", "Plaza (2nd)"}},
                {{"id", 16}, {"name", "Sinat (3rd)"}},
                {{"id", 17}, {"name", "Inventory Room (b)"}},
                {{"id", 18}, {"name", "Auditorium (b)"}},
                {{"id", 19}, {"name", "EEE Lab (b)"}},
                {{"id", 20}, {"name", "Girls Common Room"}},
                {{"id", 21}, {"name", "CR Center"}},
                {{"id", 22}, {"name", "American Corner (2nd)"}},
                {{"id", 23}, {"name", "NCC Bank"}},
                {{"id", 24}, {"name", "CSE Faculty"}},
                {{"id", 25}, {"name", "BBA Dept (2nd)"}},
                {{"id", 26}, {"name", "EEE Prog. Office"}},
                {{"id", 27}, {"name", "Lift"}},
                {{"id", 28}, {"name", "CSE Prog. Office"}},
                {{"id", 29}, {"name", "Parking"}},
                {{"id", 30}, {"name", "Medical"}},
                {{"id", 31}, {"name", "Gate (Top-Right)"}},
                {{"id", 32}, {"name", "Gate (Bottom-Right)"}},
                {{"id", 33}, {"name", "Stair"}}
            }}
        };

        res.set_content(locations.dump(), "application/json"); });

    const char *envPort = getenv("PORT");
    int port = envPort ? stoi(envPort) : 8080;
    cout << "C++ Backend running on port " << port << '\n';
    server.listen("0.0.0.0", port);
}

void addDirectedEdge(int u, int v, int weight, vector<vector<pair<int, int>>> &graph)
{
    graph[u].push_back({v, weight});
}

pair<vector<int>, int> dijkstra(int source, int destination, vector<vector<pair<int, int>>> &graph)
{
    int n = graph.size();
    vector<int> dist(n, INF);
    vector<int> parent(n, -1);

    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;

    dist[source] = 0;
    pq.push({0, source});

    while (!pq.empty())
    {
        int currentDist = pq.top().first;
        int u = pq.top().second;
        pq.pop();

        if (currentDist != dist[u])
            continue;

        if (u == destination)
            break;

        for (auto edge : graph[u])
        {
            int v = edge.first;
            int weight = edge.second;

            if (dist[u] + weight < dist[v])
            {
                dist[v] = dist[u] + weight;
                parent[v] = u;
                pq.push({dist[v], v});
            }
        }
    }

    if (dist[destination] == INF)
    {
        return {{}, -1};
    }

    vector<int> path;
    for (int v = destination; v != -1; v = parent[v])
    {
        path.push_back(v);
    }

    vector<int> exactPath;
    for (int i = path.size() - 1; i >= 0; i--)
    {
        exactPath.push_back(path[i]);
    }

    return {exactPath, dist[destination]};
}